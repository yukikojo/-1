# S-DES 加密解密系统 - 运行说明

## 运行方法

### 方法一：使用批处理文件（最简单）
直接双击 `运行程序.bat` 文件即可启动程序。

### 方法二：在IDE中运行（推荐用于开发）

#### Eclipse
1. 打开 Eclipse
2. 导入项目：File → Import → Existing Projects into Workspace
3. 选择项目文件夹
4. 找到 `src/UI/Main.java`
5. 右键 → Run As → Java Application

#### IntelliJ IDEA
1. 打开 IntelliJ IDEA
2. File → Open → 选择项目文件夹
3. 找到 `src/UI/Main.java`
4. 右键 → Run 'Main.main()'
5. 或点击类名旁边的绿色运行按钮

#### VS Code
1. 打开 VS Code
2. 打开项目文件夹
3. 找到 `src/UI/Main.java`
4. 点击类名上方的 "Run" 按钮
5. 或按 F5 运行

### 方法三：命令行运行

#### Windows PowerShell 或 CMD
```bash
# 进入项目目录
cd "项目路径"

# 运行程序
java -cp "out\production\S_DES_Project" UI.Main
```

#### 如果需要重新编译
```bash
# 编译所有Java文件
javac -d out/production/S_DES_Project -encoding UTF-8 src/UI/*.java src/functionalClass/*.java

# 然后运行
java -cp "out\production\S_DES_Project" UI.Main
```

## 系统要求

- Java JDK 8 或更高版本
- 支持图形界面的操作系统（Windows/Linux/Mac）

## 检查Java环境

在命令行输入以下命令检查Java是否安装：
```bash
java -version
```

如果显示版本信息，说明Java已安装。

## 程序功能

1. **加密功能**：
   - 支持8位二进制明文加密
   - 支持ASCII字符串加密
   - 需要10位二进制密钥

2. **解密功能**：
   - 支持8位二进制密文解密
   - 支持ASCII字符串解密
   - 需要10位二进制密钥

3. **默认密钥和明文**：
   - 密钥：`1010101010`
   - 示例明文：`11001100`
   - 示例密文：`01010011`

## 使用提示

1. 密钥必须是10位二进制数（0或1）
2. 二进制明文/密文必须是8位（0或1）
3. ASCII字符串可以输入任意文本
4. 点击"全部重置"可以清空所有输入和输出

## 常见问题

**Q: 程序无法启动？**
A: 检查Java是否安装，以及项目是否已编译。

**Q: 界面显示乱码？**
A: 确保系统支持UTF-8编码，或使用IDE运行。

**Q: 找不到主类？**
A: 确保在项目根目录运行，或使用IDE运行。

