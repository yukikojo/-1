package UI;

import javax.swing.*;
import java.awt.*;

public class ui extends JFrame{
	JFrame f;
	JPanel jpA,jpB;
	JLabel jlabA1,jlabA2,jlabA3,jlabB1,jlabB2,jlabB3;

	JTabbedPane jtbp;
	JTextField keyA,keyB,plaintext,ciphertext,plaintextASCII,ciphertextASCII;
	JTextArea outputA,outputB;
	JButton butA1,butA2,butB1,butB2;
	MyCommandListener listener,listenerB,clearlistener;
	
	public ui()
	{
		f=new JFrame("S-DES 加密解密系统");
		// 设置窗口图标和样式
		f.setLocationRelativeTo(null); // 居中显示
		
		// 使用更现代的背景色
		Color bgColor = new Color(245, 245, 250);
		Color labelColor = new Color(50, 50, 50);
		Color buttonColor = new Color(70, 130, 180); // 钢蓝色
		
		jpA=new JPanel();//面板1(加密面板)
		jpA.setBackground(bgColor);
		jpB=new JPanel();//面板2(解密面板)
		jpB.setBackground(bgColor);
		
		jlabA1=new JLabel("请输入10位二进制密钥，如：1010101010");
		jlabA1.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		jlabA1.setForeground(labelColor);
		jlabB1=new JLabel("请输入10位二进制密钥，如：1010101010");
		jlabB1.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		jlabB1.setForeground(labelColor);
		
		keyA = new JTextField(20);
		keyA.setFont(new Font("Consolas", Font.PLAIN, 13));
		keyA.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
			BorderFactory.createEmptyBorder(5, 8, 5, 8)));
		keyB = new JTextField(20);
		keyB.setFont(new Font("Consolas", Font.PLAIN, 13));
		keyB.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
			BorderFactory.createEmptyBorder(5, 8, 5, 8)));
		
		jlabA2=new JLabel("请输入8位二进制明文，如：11001100");
		jlabA2.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		jlabA2.setForeground(labelColor);
		jlabB2=new JLabel("请输入8位二进制密文，如：01010011");
		jlabB2.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		jlabB2.setForeground(labelColor);
		
		plaintext = new JTextField(20);
		plaintext.setFont(new Font("Consolas", Font.PLAIN, 13));
		plaintext.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
			BorderFactory.createEmptyBorder(5, 8, 5, 8)));
		ciphertext = new JTextField(20);
		ciphertext.setFont(new Font("Consolas", Font.PLAIN, 13));
		ciphertext.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
			BorderFactory.createEmptyBorder(5, 8, 5, 8)));
		
		jlabA3=new JLabel("请输入ASCII编码字符串明文，如：Hello S-DES");
		jlabA3.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		jlabA3.setForeground(labelColor);
		jlabB3=new JLabel("请输入ASCII编码字符串密文，如：Hello S-DES");
		jlabB3.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		jlabB3.setForeground(labelColor);
		
		plaintextASCII = new JTextField(20);
		plaintextASCII.setFont(new Font("Consolas", Font.PLAIN, 13));
		plaintextASCII.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
			BorderFactory.createEmptyBorder(5, 8, 5, 8)));
		ciphertextASCII = new JTextField(20);
		ciphertextASCII.setFont(new Font("Consolas", Font.PLAIN, 13));
		ciphertextASCII.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
			BorderFactory.createEmptyBorder(5, 8, 5, 8)));
		
		butA1=new JButton("确认生成密文");
		butA1.setFont(new Font("微软雅黑", Font.BOLD, 14));
		butA1.setBackground(buttonColor);
		butA1.setForeground(Color.WHITE);
		butA1.setFocusPainted(false);
		butA1.setBorderPainted(false);
		butA1.setCursor(new Cursor(Cursor.HAND_CURSOR));
		butA1.setPreferredSize(new Dimension(140, 35));
		
		butA2=new JButton("全部重置");
		butA2.setFont(new Font("微软雅黑", Font.BOLD, 14));
		butA2.setBackground(new Color(180, 180, 180));
		butA2.setForeground(Color.WHITE);
		butA2.setFocusPainted(false);
		butA2.setBorderPainted(false);
		butA2.setCursor(new Cursor(Cursor.HAND_CURSOR));
		butA2.setPreferredSize(new Dimension(140, 35));
		
		butB1=new JButton("确认生成明文");
		butB1.setFont(new Font("微软雅黑", Font.BOLD, 14));
		butB1.setBackground(buttonColor);
		butB1.setForeground(Color.WHITE);
		butB1.setFocusPainted(false);
		butB1.setBorderPainted(false);
		butB1.setCursor(new Cursor(Cursor.HAND_CURSOR));
		butB1.setPreferredSize(new Dimension(140, 35));
		
		butB2=new JButton("全部重置");
		butB2.setFont(new Font("微软雅黑", Font.BOLD, 14));
		butB2.setBackground(new Color(180, 180, 180));
		butB2.setForeground(Color.WHITE);
		butB2.setFocusPainted(false);
		butB2.setBorderPainted(false);
		butB2.setCursor(new Cursor(Cursor.HAND_CURSOR));
		butB2.setPreferredSize(new Dimension(140, 35));
		
		
		outputA=new JTextArea(12, 40);
		outputA.setFont(new Font("Consolas", Font.PLAIN, 12));
		outputA.setBackground(new Color(255, 255, 255));
		outputA.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
			BorderFactory.createEmptyBorder(8, 8, 8, 8)));
		outputA.setEditable(false);
		outputA.setLineWrap(true);
		outputA.setWrapStyleWord(true);
		
		outputB=new JTextArea(12, 40);
		outputB.setFont(new Font("Consolas", Font.PLAIN, 12));
		outputB.setBackground(new Color(255, 255, 255));
		outputB.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
			BorderFactory.createEmptyBorder(8, 8, 8, 8)));
		outputB.setEditable(false);
		outputB.setLineWrap(true);
		outputB.setWrapStyleWord(true);
		
		jtbp=new JTabbedPane();//采用默认的选项卡面板
		jtbp.setFont(new Font("微软雅黑", Font.BOLD, 13));
		jtbp.setBackground(bgColor);
	}
	
	public void displayWindow()
	{
//		GridLayout g = new GridLayout(3, 1);
//		jpA.setLayout(g);//设置为FlowLayout布局管理器 
//		jpB.setLayout(g);
		 
		//加密页
		//两按钮放入nBox
        Box hBoxA = Box.createHorizontalBox();
        hBoxA.add(Box.createHorizontalGlue());
        hBoxA.add(butA1);
        hBoxA.add(Box.createHorizontalStrut(20));
        hBoxA.add(butA2);
        hBoxA.add(Box.createHorizontalGlue());
        //vBox
        Box vBoxA = Box.createVerticalBox();
        vBoxA.add(Box.createVerticalStrut(15));
        vBoxA.add(jlabA1);
        vBoxA.add(Box.createVerticalStrut(5));
        vBoxA.add(keyA);
        vBoxA.add(Box.createVerticalStrut(18));
        vBoxA.add(jlabA2);
        vBoxA.add(Box.createVerticalStrut(5));
        vBoxA.add(plaintext);
        vBoxA.add(Box.createVerticalStrut(18));
        vBoxA.add(jlabA3);
        vBoxA.add(Box.createVerticalStrut(5));
        vBoxA.add(plaintextASCII);
        vBoxA.add(Box.createVerticalStrut(20));
//        vBoxA.add(hBoxA);
//        vBoxA.add(Box.createVerticalStrut(15));
//        vBoxA.add(outputA);
//        Box vBox = Box.createVerticalBox();
//        vBox.add(vBoxA);
//        vBox.add(hBoxA);
//        vBox.add(outputA);
//        jpA.add(vBox);
        jpA.setLayout(new BoxLayout(jpA, BoxLayout.Y_AXIS));
        jpA.add(Box.createVerticalStrut(10));
        jpA.add(vBoxA);
        jpA.add(Box.createVerticalStrut(10));
        jpA.add(hBoxA);
        jpA.add(Box.createVerticalStrut(10));
        jpA.add(new JScrollPane(outputA));
        jpA.add(Box.createVerticalStrut(10));
        
      //加密页
  		//两按钮放入hBox
          Box hBoxB = Box.createHorizontalBox();
          hBoxB.add(Box.createHorizontalGlue());
          hBoxB.add(butB1);
          hBoxB.add(Box.createHorizontalStrut(20));
          hBoxB.add(butB2);
          hBoxB.add(Box.createHorizontalGlue());
          //整体放入vBox
          Box vBoxB = Box.createVerticalBox();
          vBoxB.add(Box.createVerticalStrut(15));
          vBoxB.add(jlabB1);
          vBoxB.add(Box.createVerticalStrut(5));
          vBoxB.add(keyB);
          vBoxB.add(Box.createVerticalStrut(18));
          vBoxB.add(jlabB2);
          vBoxB.add(Box.createVerticalStrut(5));
          vBoxB.add(ciphertext);
          vBoxB.add(Box.createVerticalStrut(18));
          vBoxB.add(jlabB3);
          vBoxB.add(Box.createVerticalStrut(5));
          vBoxB.add(ciphertextASCII);
          vBoxB.add(Box.createVerticalStrut(20));
//          vBoxB.add(hBoxB);
//          vBoxB.add(Box.createVerticalStrut(15));
//          vBoxB.add(outputB);
        
		jpB.setLayout(new BoxLayout(jpB, BoxLayout.Y_AXIS));
		jpB.add(Box.createVerticalStrut(10));
		jpB.add(vBoxB);
		jpB.add(Box.createVerticalStrut(10));
		jpB.add(hBoxB);
		jpB.add(Box.createVerticalStrut(10));
		jpB.add(new JScrollPane(outputB));
		jpB.add(Box.createVerticalStrut(10));

		jtbp.addTab("加密", jpA);//添加选项卡进选项卡面板
		jtbp.addTab("解密", jpB);
		jtbp.setFont(new  java.awt.Font("黑体",  1,  12));
		
		
		f.setContentPane(jtbp);
		f.setSize(520, 600);
		f.setResizable(true);
		f.setMinimumSize(new Dimension(500, 550));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLocationRelativeTo(null); // 居中显示
		f.setVisible(true);
	}
	
	public void setMyCommandListener(MyCommandListener listener) {
		this.listener=listener;
		listener.setJTextField1(keyA);
		listener.setJTextField2(plaintext);
		listener.setJTextField3(plaintextASCII);
		listener.setJTextArea(outputA);
		butA1.addActionListener(listener);
		
	}
	public void setMyCommandListenerB(MyCommandListener listener) {
		listenerB=listener;
		listener.setJTextField1(keyB);
		listener.setJTextField2(ciphertext);
		listener.setJTextField3(ciphertextASCII);
		listener.setJTextArea(outputB);
		butB1.addActionListener(listener);
		
	}
	public void setMyCommandListenerClear(MyCommandListener listener) {
		clearlistener=listener;
		listener.setJTextField1(keyA);
		listener.setJTextField2(plaintext);
		listener.setJTextField3(plaintextASCII);
		listener.setJTextArea(outputA);
		keyA.addActionListener(listener);
		plaintext.addActionListener(listener);
		plaintextASCII.addActionListener(listener);
		butA2.addActionListener(listener);
		
	}
	public void setMyCommandListenerClearB(MyCommandListener listener) {
		clearlistener=listener;
		listener.setJTextField1(keyB);
		listener.setJTextField2(ciphertext);
		listener.setJTextField3(ciphertextASCII);
		listener.setJTextArea(outputB);
		keyB.addActionListener(listener);
		ciphertext.addActionListener(listener);
		ciphertextASCII.addActionListener(listener);
		butB2.addActionListener(listener);
		
	}
}

