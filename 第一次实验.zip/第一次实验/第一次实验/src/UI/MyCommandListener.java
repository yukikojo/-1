package UI;

import javax.swing.*;
import java.awt.event.*;
public interface MyCommandListener extends ActionListener  {
	public void setJTextField1(JTextField text);
	public void setJTextField2(JTextField text);
	public void setJTextField3(JTextField text);
	public void setJTextArea(JTextArea area);


}
